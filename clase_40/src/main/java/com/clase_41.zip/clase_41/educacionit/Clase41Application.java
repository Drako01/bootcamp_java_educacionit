package com.educacionit;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Clase41Application {

	public static void main(String[] args) {
		SpringApplication.run(Clase41Application.class, args);
	}

}
